export const environment = {
  production: true,
  APIEndpoint: "http://host:ip/"
};
