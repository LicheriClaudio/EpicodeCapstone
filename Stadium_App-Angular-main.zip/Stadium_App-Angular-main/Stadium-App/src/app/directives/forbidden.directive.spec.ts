import { ForbiddenDirective } from './forbidden.directive';

describe('ForbiddenDirective', () => {
  it('should create an instance', () => {
    const directive = new ForbiddenDirective();
    expect(directive).toBeTruthy();
  });
});
