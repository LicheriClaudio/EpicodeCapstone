package it.contrader.exceptions;

public class GenericException extends Exception{

        public GenericException(String message) {
            super(message);
        }
}
